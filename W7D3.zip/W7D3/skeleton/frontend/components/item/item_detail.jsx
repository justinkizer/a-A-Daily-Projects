import React from 'react';

const ItemDetail = props => {
  return (
    <div>
      {props.item.name}
    </div>
  );
};

export default ItemDetail;
